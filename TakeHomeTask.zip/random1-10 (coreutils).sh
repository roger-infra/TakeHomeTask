#!/bin/bash
# Author: Roger Sedlacek Fibiger
# Client: Adjust GmbH
# Date: April 13 2022
# Purpose: Please design a script that writes the numbers from 1 - 10 in random order.
# Each number should appear only once. You can use bash only.

max_numbers=10 # Quantity of numbers

# Just to give a whole line before the text that's going to be presented to the user
echo

# Text that's going to be presented to the user
echo "$max_numbers numbers in random order:"

# Another line
echo "--------------------"

# Creation of the array with $max_numbers
array=($(seq $max_numbers | shuf -))

# Prints the array
echo "${array[@]}"

# Prints the last line
echo "--------------------"
