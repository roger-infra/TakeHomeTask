#!/bin/bash
# Author: Roger Sedlacek Fibiger
# Client: Adjust GmbH
# Date: April 13 2022
# Purpose: Please design a script that writes the numbers from 1 - 10 in random order.
# Each number should appear only once. You can use bash only.

max_numbers=10 # Quantity of numbers
i=1 # Interactions

# Just to give a whole line before the text that's going to be presented to the user
echo

# Text that's going to be presented to the user
echo "$max_numbers numbers in random order:"

# Another line
echo "--------------------"

# Loop thats going to create the array
while [ $i -le $max_numbers ]
do
	# The variable number receives it's value from $RANDOM (an integer between 0 and 32767)
	# The "1 +" and the "% $max_numbers" guarantee that the values stays between 1 and the $max_numbers defined before
	number=$((1 + $RANDOM % $max_numbers))
	
	# Each generated number must be compared to the existing numbers in the array
	# The if clause verifies if the $number exists in the $array
	if ( dlm=$'\x1F' ; IFS="$dlm" ; [[ "$dlm${array[*]}$dlm" == *"$dlm${number}$dlm"* ]] ) ;
	# If it exists, it does nothing and returns to the loop, not adding the repeated number to the array
	then
  		:
	# If it not exists, the number is added to the array and the counter "i" is incremented
	else
		array[i]+=$number
		let "i++"
	fi

done

# Prints the array
echo ${array[*]}

# Prints the last line
echo "--------------------"
